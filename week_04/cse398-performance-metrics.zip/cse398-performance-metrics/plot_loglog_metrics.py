import re
import matplotlib.pyplot as plt

input_file = "results/baseline_results.txt"

threads = []
parallel_times = []
sequential_time = None

pattern = re.compile(
    r"mode=(.*?),threads=(\d+),N=(\d+),elapsed_seconds=([0-9.]+)"
)

with open(input_file, "r") as f:
    for line in f:
        line = line.strip()
        match = pattern.match(line)

        if match:
            mode = match.group(1)
            thread_count = int(match.group(2))
            elapsed = float(match.group(4))

            if mode == "sequential":
                sequential_time = elapsed
            elif mode == "parallel":
                threads.append(thread_count)
                parallel_times.append(elapsed)

rows = sorted(zip(threads, parallel_times))
threads = [row[0] for row in rows]
parallel_times = [row[1] for row in rows]

ideal_times = [sequential_time / thread for thread in threads]

# Figure 1: Linear elapsed-time plot
plt.figure(figsize=(7, 4.5))
plt.plot(
    threads,
    parallel_times,
    marker="o",
    linestyle="-",
    label="Measured Elapsed Time"
)
plt.plot(
    threads,
    ideal_times,
    marker="s",
    linestyle="--",
    label="Ideal Linear Scaling"
)
plt.xlabel("Number of Threads")
plt.ylabel("Elapsed Time (seconds)")
plt.title("Linear Time Plot")
plt.legend()
plt.grid(True, linestyle=":")
plt.tight_layout()
plt.savefig("results/linear_time_scaling.png", dpi=300)
plt.close()

# Figure 2: Log-log elapsed-time plot
plt.figure(figsize=(7, 4.5))
plt.loglog(
    threads,
    parallel_times,
    marker="o",
    linestyle="-",
    base=2,
    label="Measured Elapsed Time"
)
plt.loglog(
    threads,
    ideal_times,
    marker="s",
    linestyle="--",
    base=2,
    label="Ideal Linear Scaling"
)
plt.xlabel("Number of Threads")
plt.ylabel("Elapsed Time (seconds)")
plt.title("Log-Log Time Plot")
plt.legend()
plt.grid(True, which="both", linestyle=":")
plt.tight_layout()
plt.savefig("results/loglog_time_scaling.png", dpi=300)
plt.close()

print("Saved:")
print("  results/linear_time_scaling.png")
print("  results/loglog_time_scaling.png")