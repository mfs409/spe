import re
import matplotlib.pyplot as plt

input_file = "results/parallel_time_results.txt"

data = {
    "blocking_wait": {"threads": [], "elapsed": [], "cpu": []},
    "spin_wait": {"threads": [], "elapsed": [], "cpu": []},
}

pattern = re.compile(
    r"mode=(.*?),threads=(\d+),rounds=(\d+),wait_ms=(\d+),"
    r"elapsed_seconds=([0-9.]+),cpu_seconds=([0-9.]+),cpu_to_elapsed_ratio=([0-9.]+)"
)

with open(input_file, "r") as f:
    for line in f:
        line = line.strip()
        match = pattern.match(line)
        if match:
            mode = match.group(1)
            threads = int(match.group(2))
            elapsed = float(match.group(5))
            cpu = float(match.group(6))

            data[mode]["threads"].append(threads)
            data[mode]["elapsed"].append(elapsed)
            data[mode]["cpu"].append(cpu)

for mode in data:
    zipped = sorted(zip(data[mode]["threads"],
                        data[mode]["elapsed"],
                        data[mode]["cpu"]))
    data[mode]["threads"] = [x[0] for x in zipped]
    data[mode]["elapsed"] = [x[1] for x in zipped]
    data[mode]["cpu"] = [x[2] for x in zipped]

# Figure 1: Elapsed Time
plt.figure(figsize=(7, 4.5))
plt.plot(
    data["blocking_wait"]["threads"],
    data["blocking_wait"]["elapsed"],
    marker='o',
    linestyle='-',
    label='Blocking Wait'
)
plt.plot(
    data["spin_wait"]["threads"],
    data["spin_wait"]["elapsed"],
    marker='s',
    linestyle='--',
    label='Spin Wait'
)
plt.xlabel("Number of Threads")
plt.ylabel("Elapsed Time (seconds)")
plt.title("Elapsed Time")
plt.legend()
plt.grid(True, linestyle=':')
plt.tight_layout()
plt.savefig("results/elapsed_time.png", dpi=300)
plt.close()

# Figure 2: Total CPU Time
plt.figure(figsize=(7, 4.5))
plt.plot(
    data["blocking_wait"]["threads"],
    data["blocking_wait"]["cpu"],
    marker='o',
    linestyle='-',
    label='Blocking Wait'
)
plt.plot(
    data["spin_wait"]["threads"],
    data["spin_wait"]["cpu"],
    marker='s',
    linestyle='--',
    label='Spin Wait'
)
plt.xlabel("Number of Threads")
plt.ylabel("Total CPU Time (seconds)")
plt.title("Total CPU Time")
plt.legend()
plt.grid(True, linestyle=':')
plt.tight_layout()
plt.savefig("results/total_cpu_time.png", dpi=300)
plt.close()

print("Saved:")
print("  results/elapsed_time.png")
print("  results/total_cpu_time.png")