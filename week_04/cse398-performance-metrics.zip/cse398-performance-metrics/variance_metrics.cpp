#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

using Clock = std::chrono::steady_clock;

volatile std::uint64_t global_sink = 0;

class TestAndSetLock {
private:
    std::atomic_flag flag = ATOMIC_FLAG_INIT;

public:
    void lock() {
        while (flag.test_and_set(std::memory_order_acquire)) {
        }
    }

    void unlock() {
        flag.clear(std::memory_order_release);
    }
};

std::uint64_t small_work(std::uint64_t value, int iterations) {
    for (int i = 0; i < iterations; i++) {
        value ^= value << 13;
        value ^= value >> 7;
        value ^= value << 17;
    }
    return value;
}

double elapsed_seconds(Clock::time_point start, Clock::time_point end) {
    return std::chrono::duration<double>(end - start).count();
}

double run_tas_lock_once(int threads, int iterations, int critical_work) {
    TestAndSetLock lock;
    std::uint64_t shared_counter = 0;
    std::vector<std::thread> workers;

    auto start = Clock::now();

    for (int t = 0; t < threads; t++) {
        workers.emplace_back([&, t]() {
            std::uint64_t local = static_cast<std::uint64_t>(t + 1);

            for (int i = 0; i < iterations; i++) {
                lock.lock();

                shared_counter += 1;
                local = small_work(local + shared_counter, critical_work);

                lock.unlock();

                local = small_work(local, 5);
            }

            global_sink += local;
        });
    }

    for (auto& worker : workers) {
        worker.join();
    }

    auto end = Clock::now();

    global_sink += shared_counter;
    return elapsed_seconds(start, end);
}

double run_mutex_once(int threads, int iterations, int critical_work) {
    std::mutex mutex;
    std::uint64_t shared_counter = 0;
    std::vector<std::thread> workers;

    auto start = Clock::now();

    for (int t = 0; t < threads; t++) {
        workers.emplace_back([&, t]() {
            std::uint64_t local = static_cast<std::uint64_t>(t + 1);

            for (int i = 0; i < iterations; i++) {
                {
                    std::lock_guard<std::mutex> guard(mutex);

                    shared_counter += 1;
                    local = small_work(local + shared_counter, critical_work);
                }

                local = small_work(local, 5);
            }

            global_sink += local;
        });
    }

    for (auto& worker : workers) {
        worker.join();
    }

    auto end = Clock::now();

    global_sink += shared_counter;
    return elapsed_seconds(start, end);
}

void summarize(const std::string& mode,
               int threads,
               int iterations,
               int runs,
               int critical_work,
               const std::vector<double>& times) {
    double sum = 0.0;
    double min_value = times[0];
    double max_value = times[0];

    for (double value : times) {
        sum += value;
        min_value = std::min(min_value, value);
        max_value = std::max(max_value, value);
    }

    double mean = sum / static_cast<double>(times.size());

    double variance = 0.0;
    for (double value : times) {
        double diff = value - mean;
        variance += diff * diff;
    }

    variance /= static_cast<double>(times.size());
    double stddev = std::sqrt(variance);
    double coefficient_of_variation = stddev / mean;

    std::cout << std::fixed << std::setprecision(6)
              << "mode=" << mode
              << ",threads=" << threads
              << ",iterations=" << iterations
              << ",runs=" << runs
              << ",critical_work=" << critical_work
              << ",mean_seconds=" << mean
              << ",stddev_seconds=" << stddev
              << ",min_seconds=" << min_value
              << ",max_seconds=" << max_value
              << ",coefficient_of_variation=" << coefficient_of_variation
              << "\n";
}

void run_experiment(const std::string& mode,
                    int threads,
                    int iterations,
                    int runs,
                    int critical_work) {
    std::vector<double> times;
    times.reserve(runs);

    for (int r = 0; r < runs; r++) {
        double seconds;

        if (mode == "tas_lock") {
            seconds = run_tas_lock_once(threads, iterations, critical_work);
        } else if (mode == "mutex") {
            seconds = run_mutex_once(threads, iterations, critical_work);
        } else {
            std::cerr << "Unknown mode\n";
            std::exit(1);
        }

        times.push_back(seconds);

        std::cout << std::fixed << std::setprecision(6)
                  << "sample_mode=" << mode
                  << ",threads=" << threads
                  << ",run=" << r + 1
                  << ",seconds=" << seconds
                  << "\n";
    }

    summarize(mode, threads, iterations, runs, critical_work, times);
}

void print_usage() {
    std::cerr << "Usage:\n"
              << "  ./variance_metrics tas_lock [threads] [iterations] [runs] [critical_work]\n"
              << "  ./variance_metrics mutex [threads] [iterations] [runs] [critical_work]\n";
}

int main(int argc, char** argv) {
    if (argc < 2) {
        print_usage();
        return 1;
    }

    std::string mode = argv[1];

    int threads = 8;
    int iterations = 100000;
    int runs = 10;
    int critical_work = 50;

    if (argc >= 3) {
        threads = std::atoi(argv[2]);
    }

    if (argc >= 4) {
        iterations = std::atoi(argv[3]);
    }

    if (argc >= 5) {
        runs = std::atoi(argv[4]);
    }

    if (argc >= 6) {
        critical_work = std::atoi(argv[5]);
    }

    if (threads <= 0 || iterations <= 0 || runs <= 0 || critical_work < 0) {
        print_usage();
        return 1;
    }

    run_experiment(mode, threads, iterations, runs, critical_work);

    std::cerr << "sink=" << global_sink << "\n";
    return 0;
}