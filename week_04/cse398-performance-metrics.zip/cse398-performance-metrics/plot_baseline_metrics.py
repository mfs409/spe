import re
import matplotlib.pyplot as plt

input_file = "results/baseline_results.txt"

threads = []
parallel_times = []
sequential_time = None

pattern = re.compile(
    r"mode=(.*?),threads=(\d+),N=(\d+),elapsed_seconds=([0-9.]+)"
)

with open(input_file, "r") as f:
    for line in f:
        line = line.strip()
        match = pattern.match(line)
        if match:
            mode = match.group(1)
            thread_count = int(match.group(2))
            elapsed = float(match.group(4))

            if mode == "sequential":
                sequential_time = elapsed
            elif mode == "parallel":
                threads.append(thread_count)
                parallel_times.append(elapsed)

zipped = sorted(zip(threads, parallel_times))
threads = [x[0] for x in zipped]
parallel_times = [x[1] for x in zipped]

sequential_times = [sequential_time for _ in threads]

plt.figure(figsize=(7, 4.5))
plt.plot(
    threads,
    parallel_times,
    marker="o",
    linestyle="-",
    label="Parallel Implementation"
)
plt.plot(
    threads,
    sequential_times,
    marker="s",
    linestyle="--",
    label="Sequential Baseline"
)
plt.xlabel("Number of Threads")
plt.ylabel("Elapsed Time (seconds)")
plt.title("Elapsed Time with Sequential Baseline")
plt.legend()
plt.grid(True, linestyle=":")
plt.tight_layout()
plt.savefig("results/baseline_elapsed_time.png", dpi=300)
plt.close()

print("Saved:")
print("  results/baseline_elapsed_time.png")