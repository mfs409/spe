import re
import matplotlib.pyplot as plt

input_file = "results/variance_results.txt"

data = {
    "tas_lock": {"threads": [], "mean": [], "stddev": [], "cv": []},
    "mutex": {"threads": [], "mean": [], "stddev": [], "cv": []},
}

pattern = re.compile(
    r"mode=(.*?),threads=(\d+),iterations=(\d+),runs=(\d+),critical_work=(\d+),"
    r"mean_seconds=([0-9.]+),stddev_seconds=([0-9.]+),min_seconds=([0-9.]+),"
    r"max_seconds=([0-9.]+),coefficient_of_variation=([0-9.]+)"
)

with open(input_file, "r") as f:
    for line in f:
        line = line.strip()
        match = pattern.match(line)
        if match:
            mode = match.group(1)
            threads = int(match.group(2))
            mean = float(match.group(6))
            stddev = float(match.group(7))
            cv = float(match.group(10))

            data[mode]["threads"].append(threads)
            data[mode]["mean"].append(mean)
            data[mode]["stddev"].append(stddev)
            data[mode]["cv"].append(cv)

for mode in data:
    rows = sorted(zip(
        data[mode]["threads"],
        data[mode]["mean"],
        data[mode]["stddev"],
        data[mode]["cv"]
    ))

    data[mode]["threads"] = [row[0] for row in rows]
    data[mode]["mean"] = [row[1] for row in rows]
    data[mode]["stddev"] = [row[2] for row in rows]
    data[mode]["cv"] = [row[3] for row in rows]

plt.figure(figsize=(7, 4.5))
plt.errorbar(
    data["tas_lock"]["threads"],
    data["tas_lock"]["mean"],
    yerr=data["tas_lock"]["stddev"],
    marker="o",
    linestyle="-",
    capsize=4,
    label="Test-and-Set Lock"
)
plt.errorbar(
    data["mutex"]["threads"],
    data["mutex"]["mean"],
    yerr=data["mutex"]["stddev"],
    marker="s",
    linestyle="--",
    capsize=4,
    label="Mutex"
)
plt.xlabel("Number of Threads")
plt.ylabel("Elapsed Time (seconds)")
plt.title("Elapsed Time Variation")
plt.legend()
plt.grid(True, linestyle=":")
plt.tight_layout()
plt.savefig("results/variance_elapsed_time.png", dpi=300)
plt.close()

plt.figure(figsize=(7, 4.5))
plt.plot(
    data["tas_lock"]["threads"],
    data["tas_lock"]["cv"],
    marker="o",
    linestyle="-",
    label="Test-and-Set Lock"
)
plt.plot(
    data["mutex"]["threads"],
    data["mutex"]["cv"],
    marker="s",
    linestyle="--",
    label="Mutex"
)
plt.xlabel("Number of Threads")
plt.ylabel("Coefficient of Variation")
plt.title("Run-to-Run Variability")
plt.legend()
plt.grid(True, linestyle=":")
plt.tight_layout()
plt.savefig("results/variance_coefficient.png", dpi=300)
plt.close()

print("Saved:")
print("  results/variance_elapsed_time.png")
print("  results/variance_coefficient.png")