#include <algorithm>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <map>
#include <numeric>
#include <random>
#include <string>
#include <unordered_map>
#include <vector>

using Clock = std::chrono::steady_clock;

volatile std::uint64_t global_sink = 0;

std::vector<std::uint32_t> make_cycle(std::size_t n) {
    std::vector<std::uint32_t> permutation(n);
    std::iota(permutation.begin(), permutation.end(), 0);

    std::mt19937 rng(12345);
    std::shuffle(permutation.begin(), permutation.end(), rng);

    std::vector<std::uint32_t> next(n);

    for (std::size_t i = 0; i < n; i++) {
        std::uint32_t current = permutation[i];
        std::uint32_t following = permutation[(i + 1) % n];
        next[current] = following;
    }

    return next;
}

std::vector<std::uint32_t> make_queries(std::size_t query_count, std::size_t n) {
    std::vector<std::uint32_t> queries(query_count);

    std::mt19937 rng(54321);
    std::uniform_int_distribution<std::uint32_t> dist(
        0,
        static_cast<std::uint32_t>(n - 1)
    );

    for (std::size_t i = 0; i < query_count; i++) {
        queries[i] = dist(rng);
    }

    return queries;
}

template <typename Function>
double time_seconds(Function&& function) {
    auto start = Clock::now();
    function();
    auto end = Clock::now();

    return std::chrono::duration<double>(end - start).count();
}

void print_result(const std::string& structure,
                  const std::string& mode,
                  std::size_t queries,
                  double seconds) {
    double ns_per_lookup = seconds * 1e9 / queries;
    double lookups_per_second = queries / seconds;

    std::cout << "structure=" << structure
              << ",mode=" << mode
              << ",queries=" << queries
              << ",seconds=" << seconds
              << ",ns_per_lookup=" << ns_per_lookup
              << ",lookups_per_second=" << lookups_per_second
              << "\n";
}

void benchmark_vector_latency(const std::vector<std::uint32_t>& next,
                              std::size_t query_count) {
    std::uint32_t key = 0;

    double seconds = time_seconds([&]() {
        for (std::size_t i = 0; i < query_count; i++) {
            key = next[key];
        }
    });

    global_sink += key;
    print_result("vector", "latency", query_count, seconds);
}

void benchmark_vector_throughput(const std::vector<std::uint32_t>& next,
                                 const std::vector<std::uint32_t>& queries) {
    std::uint64_t sum = 0;

    double seconds = time_seconds([&]() {
        for (std::uint32_t key : queries) {
            sum += next[key];
        }
    });

    global_sink += sum;
    print_result("vector", "throughput", queries.size(), seconds);
}

void benchmark_unordered_map_latency(
    const std::unordered_map<std::uint32_t, std::uint32_t>& table,
    std::size_t query_count) {
    std::uint32_t key = 0;

    double seconds = time_seconds([&]() {
        for (std::size_t i = 0; i < query_count; i++) {
            auto it = table.find(key);
            key = it->second;
        }
    });

    global_sink += key;
    print_result("unordered_map", "latency", query_count, seconds);
}

void benchmark_unordered_map_throughput(
    const std::unordered_map<std::uint32_t, std::uint32_t>& table,
    const std::vector<std::uint32_t>& queries) {
    std::uint64_t sum = 0;

    double seconds = time_seconds([&]() {
        for (std::uint32_t key : queries) {
            auto it = table.find(key);
            sum += it->second;
        }
    });

    global_sink += sum;
    print_result("unordered_map", "throughput", queries.size(), seconds);
}

void benchmark_map_latency(const std::map<std::uint32_t, std::uint32_t>& tree,
                           std::size_t query_count) {
    std::uint32_t key = 0;

    double seconds = time_seconds([&]() {
        for (std::size_t i = 0; i < query_count; i++) {
            auto it = tree.find(key);
            key = it->second;
        }
    });

    global_sink += key;
    print_result("map", "latency", query_count, seconds);
}

void benchmark_map_throughput(const std::map<std::uint32_t, std::uint32_t>& tree,
                              const std::vector<std::uint32_t>& queries) {
    std::uint64_t sum = 0;

    double seconds = time_seconds([&]() {
        for (std::uint32_t key : queries) {
            auto it = tree.find(key);
            sum += it->second;
        }
    });

    global_sink += sum;
    print_result("map", "throughput", queries.size(), seconds);
}

void print_usage() {
    std::cerr << "Usage:\n"
              << "  ./ds_metrics vector latency [N] [Q]\n"
              << "  ./ds_metrics vector throughput [N] [Q]\n"
              << "  ./ds_metrics unordered_map latency [N] [Q]\n"
              << "  ./ds_metrics unordered_map throughput [N] [Q]\n"
              << "  ./ds_metrics map latency [N] [Q]\n"
              << "  ./ds_metrics map throughput [N] [Q]\n\n"
              << "N = number of elements in the data structure\n"
              << "Q = number of lookup operations\n";
}

int main(int argc, char** argv) {
    if (argc < 3) {
        print_usage();
        return 1;
    }

    std::string structure = argv[1];
    std::string mode = argv[2];

    std::size_t n = 1000000;
    std::size_t query_count = 5000000;

    if (argc >= 4) {
        n = std::stoull(argv[3]);
    }

    if (argc >= 5) {
        query_count = std::stoull(argv[4]);
    }

    std::cerr << "Building dataset: N=" << n
              << ", queries=" << query_count << "\n";

    std::vector<std::uint32_t> next = make_cycle(n);
    std::vector<std::uint32_t> queries = make_queries(query_count, n);

    if (structure == "vector") {
        if (mode == "latency") {
            benchmark_vector_latency(next, query_count);
        } else if (mode == "throughput") {
            benchmark_vector_throughput(next, queries);
        } else {
            print_usage();
            return 1;
        }
    } else if (structure == "unordered_map") {
        std::unordered_map<std::uint32_t, std::uint32_t> table;
        table.reserve(n * 2);
        table.max_load_factor(0.7);

        for (std::size_t i = 0; i < n; i++) {
            table.emplace(static_cast<std::uint32_t>(i), next[i]);
        }

        if (mode == "latency") {
            benchmark_unordered_map_latency(table, query_count);
        } else if (mode == "throughput") {
            benchmark_unordered_map_throughput(table, queries);
        } else {
            print_usage();
            return 1;
        }
    } else if (structure == "map") {
        std::map<std::uint32_t, std::uint32_t> tree;

        for (std::size_t i = 0; i < n; i++) {
            tree.emplace(static_cast<std::uint32_t>(i), next[i]);
        }

        if (mode == "latency") {
            benchmark_map_latency(tree, query_count);
        } else if (mode == "throughput") {
            benchmark_map_throughput(tree, queries);
        } else {
            print_usage();
            return 1;
        }
    } else {
        print_usage();
        return 1;
    }

    std::cerr << "sink=" << global_sink << "\n";
    return 0;
}