#!/bin/bash

RESULT_DIR="results"
RESULT_FILE="${RESULT_DIR}/variance_results.txt"

THREADS_LIST="2 4 8 16"
ITERATIONS=100000
RUNS=10
CRITICAL_WORK=50

mkdir -p "${RESULT_DIR}"

{
    echo "Variance and Lock Contention Experiment"
    echo "Host: $(hostname)"
    echo "Compiler: $(g++ --version | head -n 1)"
    echo "System: $(uname -a)"
    echo
    echo "Iterations per thread=${ITERATIONS}"
    echo "Runs per configuration=${RUNS}"
    echo "Critical work=${CRITICAL_WORK}"
    echo

    for threads in ${THREADS_LIST}; do
        ./variance_metrics tas_lock ${threads} ${ITERATIONS} ${RUNS} ${CRITICAL_WORK}
        echo
    done

    for threads in ${THREADS_LIST}; do
        ./variance_metrics mutex ${threads} ${ITERATIONS} ${RUNS} ${CRITICAL_WORK}
        echo
    done

} > "${RESULT_FILE}" 2>&1

echo "Saved results to ${RESULT_FILE}"