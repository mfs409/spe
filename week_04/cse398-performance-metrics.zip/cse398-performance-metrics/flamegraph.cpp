#include <chrono>
#include <cstdint>
#include <iostream>
#include <map>
#include <random>
#include <unordered_map>
#include <vector>

volatile std::uint64_t global_sink = 0;

__attribute__((noinline))
std::uint32_t normalize_key(std::uint32_t key, std::uint32_t limit) {
    key ^= key >> 16;
    key *= 0x7feb352d;
    key ^= key >> 15;
    key *= 0x846ca68b;
    key ^= key >> 16;
    return key % limit;
}

__attribute__((noinline))
std::uint32_t shared_postprocess(std::uint32_t value) {
    value ^= value >> 13;
    value *= 0x5bd1e995;
    value ^= value >> 15;
    return value;
}

__attribute__((noinline))
std::uint32_t vector_lookup(const std::vector<std::uint32_t>& data,
                            std::uint32_t key) {
    std::uint32_t idx = normalize_key(key, static_cast<std::uint32_t>(data.size()));
    std::uint32_t value = data[idx];
    return shared_postprocess(value);
}

__attribute__((noinline))
std::uint32_t hash_lookup(const std::unordered_map<std::uint32_t, std::uint32_t>& table,
                          std::uint32_t key,
                          std::uint32_t limit) {
    std::uint32_t idx = normalize_key(key, limit);
    std::uint32_t value = table.find(idx)->second;
    return shared_postprocess(value);
}

__attribute__((noinline))
std::uint32_t tree_lookup(const std::map<std::uint32_t, std::uint32_t>& tree,
                          std::uint32_t key,
                          std::uint32_t limit) {
    std::uint32_t idx = normalize_key(key, limit);
    std::uint32_t value = tree.find(idx)->second;
    return shared_postprocess(value);
}

__attribute__((noinline))
std::uint32_t process_vector_path(const std::vector<std::uint32_t>& data,
                                  std::uint32_t key) {
    return vector_lookup(data, key);
}

__attribute__((noinline))
std::uint32_t process_hash_path(const std::unordered_map<std::uint32_t, std::uint32_t>& table,
                                std::uint32_t key,
                                std::uint32_t limit) {
    return hash_lookup(table, key, limit);
}

__attribute__((noinline))
std::uint32_t process_tree_path(const std::map<std::uint32_t, std::uint32_t>& tree,
                                std::uint32_t key,
                                std::uint32_t limit) {
    return tree_lookup(tree, key, limit);
}

std::vector<std::uint32_t> make_values(std::size_t n) {
    std::vector<std::uint32_t> values(n);

    for (std::size_t i = 0; i < n; i++) {
        values[i] = static_cast<std::uint32_t>((i * 2654435761ULL) % n);
    }

    return values;
}

std::vector<std::uint32_t> make_queries(std::size_t q, std::size_t n) {
    std::vector<std::uint32_t> queries(q);

    std::mt19937 rng(12345);
    std::uniform_int_distribution<std::uint32_t> dist(
        0,
        static_cast<std::uint32_t>(n - 1)
    );

    for (std::size_t i = 0; i < q; i++) {
        queries[i] = dist(rng);
    }

    return queries;
}

void run_workload(std::size_t n, std::size_t q) {
    std::vector<std::uint32_t> values = make_values(n);
    std::vector<std::uint32_t> queries = make_queries(q, n);

    std::unordered_map<std::uint32_t, std::uint32_t> table;
    table.reserve(n * 2);
    table.max_load_factor(0.7);

    std::map<std::uint32_t, std::uint32_t> tree;

    for (std::size_t i = 0; i < n; i++) {
        table.emplace(static_cast<std::uint32_t>(i), values[i]);
        tree.emplace(static_cast<std::uint32_t>(i), values[i]);
    }

    std::uint64_t sum = 0;

    for (std::size_t i = 0; i < q; i++) {
        std::uint32_t key = queries[i];

        if (i % 3 == 0) {
            sum += process_vector_path(values, key);
        } else if (i % 3 == 1) {
            sum += process_hash_path(table, key, static_cast<std::uint32_t>(n));
        } else {
            sum += process_tree_path(tree, key, static_cast<std::uint32_t>(n));
        }
    }

    global_sink += sum;
}

int main(int argc, char** argv) {
    std::size_t n = 1000000;
    std::size_t q = 5000000;

    if (argc >= 2) {
        n = std::stoull(argv[1]);
    }

    if (argc >= 3) {
        q = std::stoull(argv[2]);
    }

    auto start = std::chrono::steady_clock::now();

    run_workload(n, q);

    auto end = std::chrono::steady_clock::now();
    double seconds = std::chrono::duration<double>(end - start).count();

    std::cout << "N=" << n
              << ",Q=" << q
              << ",seconds=" << seconds
              << ",sink=" << global_sink
              << "\n";

    return 0;
}
