#!/bin/bash

RESULT_DIR="results"
RESULT_FILE="${RESULT_DIR}/parallel_time_results.txt"

mkdir -p "${RESULT_DIR}"

{
    echo "Parallel CPU Time vs Elapsed Time Experiment"
    echo "Host: $(hostname)"
    echo "Compiler: $(g++ --version | head -n 1)"
    echo "System: $(uname -a)"
    echo

    echo "Blocking wait experiment"
    ./parallel_time_metrics blocking_wait 8 1000 1000
    ./parallel_time_metrics blocking_wait 16 1000 1000
    echo

    echo "Spin wait experiment"
    ./parallel_time_metrics spin_wait 8 1000 1000
    ./parallel_time_metrics spin_wait 16 1000 1000

} > "${RESULT_FILE}" 2>&1

echo "Saved results to ${RESULT_FILE}"