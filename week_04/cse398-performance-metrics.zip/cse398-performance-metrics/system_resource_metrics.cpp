#include <chrono>
#include <cstdint>
#include <cstring>
#include <fcntl.h>
#include <iostream>
#include <string>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <vector>

using Clock = std::chrono::steady_clock;

volatile std::uint64_t global_sink = 0;

template <typename Function>
double time_seconds(Function&& function) {
    auto start = Clock::now();
    function();
    auto end = Clock::now();

    return std::chrono::duration<double>(end - start).count();
}

void benchmark_memory_bandwidth(std::size_t size_mb, int passes) {
    std::size_t bytes = size_mb * 1024ULL * 1024ULL;

    std::vector<std::uint8_t> source(bytes, 1);
    std::vector<std::uint8_t> destination(bytes, 0);

    double seconds = time_seconds([&]() {
        for (int pass = 0; pass < passes; pass++) {
            std::memcpy(destination.data(), source.data(), bytes);
        }
    });

    std::uint64_t checksum = 0;
    for (std::size_t i = 0; i < destination.size(); i += 4096) {
        checksum += destination[i];
    }

    global_sink += checksum;

    double total_bytes = static_cast<double>(bytes) * passes;
    double gb_transferred = total_bytes / 1e9;
    double gb_per_second = gb_transferred / seconds;

    std::cout << "test=memory_bandwidth"
              << ",size_mb=" << size_mb
              << ",passes=" << passes
              << ",seconds=" << seconds
              << ",gb_transferred=" << gb_transferred
              << ",gb_per_second=" << gb_per_second
              << "\n";
}

void benchmark_disk_write_bandwidth(const std::string& filename,
                                    std::size_t size_mb,
                                    std::size_t block_kb) {
    std::size_t total_bytes = size_mb * 1024ULL * 1024ULL;
    std::size_t block_bytes = block_kb * 1024ULL;

    std::vector<char> buffer(block_bytes, 'x');

    int fd = open(filename.c_str(),
                  O_CREAT | O_WRONLY | O_TRUNC,
                  0644);

    if (fd < 0) {
        perror("open");
        return;
    }

    double seconds = time_seconds([&]() {
        std::size_t written = 0;

        while (written < total_bytes) {
            std::size_t to_write = std::min(block_bytes, total_bytes - written);
            ssize_t rc = write(fd, buffer.data(), to_write);

            if (rc < 0) {
                perror("write");
                break;
            }

            written += static_cast<std::size_t>(rc);
        }

        fsync(fd);
    });

    close(fd);

    double gb_written = static_cast<double>(total_bytes) / 1e9;
    double gb_per_second = gb_written / seconds;

    std::cout << "test=disk_write_bandwidth"
              << ",file=" << filename
              << ",size_mb=" << size_mb
              << ",block_kb=" << block_kb
              << ",seconds=" << seconds
              << ",gb_written=" << gb_written
              << ",gb_per_second=" << gb_per_second
              << "\n";
}

void benchmark_syscall_latency(std::size_t iterations) {
    pid_t sink = 0;

    double seconds = time_seconds([&]() {
        for (std::size_t i = 0; i < iterations; i++) {
            sink ^= getpid();
        }
    });

    global_sink += static_cast<std::uint64_t>(sink);

    double ns_per_syscall = seconds * 1e9 / iterations;
    double syscalls_per_second = iterations / seconds;

    std::cout << "test=syscall_latency"
              << ",syscall=getpid"
              << ",iterations=" << iterations
              << ",seconds=" << seconds
              << ",ns_per_syscall=" << ns_per_syscall
              << ",syscalls_per_second=" << syscalls_per_second
              << "\n";
}

void benchmark_file_create_latency(const std::string& directory,
                                   std::size_t file_count) {
    double seconds = time_seconds([&]() {
        for (std::size_t i = 0; i < file_count; i++) {
            std::string path =
                directory + "/small_file_" + std::to_string(i) + ".tmp";

            int fd = open(path.c_str(),
                          O_CREAT | O_WRONLY | O_TRUNC,
                          0644);

            if (fd < 0) {
                perror("open");
                break;
            }

            const char* text = "x";
            write(fd, text, 1);
            close(fd);
        }
    });

    double us_per_file = seconds * 1e6 / file_count;
    double files_per_second = file_count / seconds;

    std::cout << "test=file_create_latency"
              << ",directory=" << directory
              << ",files=" << file_count
              << ",seconds=" << seconds
              << ",us_per_file=" << us_per_file
              << ",files_per_second=" << files_per_second
              << "\n";
}

void cleanup_created_files(const std::string& directory,
                           std::size_t file_count) {
    for (std::size_t i = 0; i < file_count; i++) {
        std::string path =
            directory + "/small_file_" + std::to_string(i) + ".tmp";
        unlink(path.c_str());
    }
}

void print_usage() {
    std::cerr << "Usage:\n"
              << "  ./system_metrics memory [size_mb] [passes]\n"
              << "  ./system_metrics disk_write [filename] [size_mb] [block_kb]\n"
              << "  ./system_metrics syscall [iterations]\n"
              << "  ./system_metrics file_create [directory] [file_count]\n\n"
              << "Examples:\n"
              << "  ./system_metrics memory 512 5\n"
              << "  ./system_metrics disk_write disk_test_file.tmp 512 1024\n"
              << "  ./system_metrics syscall 10000000\n"
              << "  ./system_metrics file_create . 10000\n";
}

int main(int argc, char** argv) {
    if (argc < 2) {
        print_usage();
        return 1;
    }

    std::string mode = argv[1];

    if (mode == "memory") {
        std::size_t size_mb = 512;
        int passes = 5;

        if (argc >= 3) {
            size_mb = std::stoull(argv[2]);
        }

        if (argc >= 4) {
            passes = std::stoi(argv[3]);
        }

        benchmark_memory_bandwidth(size_mb, passes);
    } else if (mode == "disk_write") {
        std::string filename = "disk_test_file.tmp";
        std::size_t size_mb = 512;
        std::size_t block_kb = 1024;

        if (argc >= 3) {
            filename = argv[2];
        }

        if (argc >= 4) {
            size_mb = std::stoull(argv[3]);
        }

        if (argc >= 5) {
            block_kb = std::stoull(argv[4]);
        }

        benchmark_disk_write_bandwidth(filename, size_mb, block_kb);
    } else if (mode == "syscall") {
        std::size_t iterations = 10000000;

        if (argc >= 3) {
            iterations = std::stoull(argv[2]);
        }

        benchmark_syscall_latency(iterations);
    } else if (mode == "file_create") {
        std::string directory = ".";
        std::size_t file_count = 10000;

        if (argc >= 3) {
            directory = argv[2];
        }

        if (argc >= 4) {
            file_count = std::stoull(argv[3]);
        }

        benchmark_file_create_latency(directory, file_count);
        cleanup_created_files(directory, file_count);
    } else {
        print_usage();
        return 1;
    }

    std::cerr << "sink=" << global_sink << "\n";
    return 0;
}