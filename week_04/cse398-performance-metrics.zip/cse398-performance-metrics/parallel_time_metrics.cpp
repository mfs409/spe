#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <mutex>
#include <string>
#include <thread>
#include <vector>
#include <sys/resource.h>

using Clock = std::chrono::steady_clock;

volatile std::uint64_t global_sink = 0;

double get_cpu_seconds() {
    rusage usage{};
    getrusage(RUSAGE_SELF, &usage);

    double user_seconds =
        usage.ru_utime.tv_sec + usage.ru_utime.tv_usec / 1000000.0;

    double system_seconds =
        usage.ru_stime.tv_sec + usage.ru_stime.tv_usec / 1000000.0;

    return user_seconds + system_seconds;
}

std::uint64_t small_cpu_work(std::uint64_t seed, std::size_t iterations) {
    std::uint64_t value = seed;

    for (std::size_t i = 0; i < iterations; i++) {
        value ^= value << 13;
        value ^= value >> 7;
        value ^= value << 17;
    }

    return value;
}

void print_result(const std::string& mode,
                  int threads,
                  int rounds,
                  int wait_ms,
                  double elapsed_seconds,
                  double cpu_seconds) {
    double cpu_to_elapsed_ratio = cpu_seconds / elapsed_seconds;

    std::cout << "mode=" << mode
              << ",threads=" << threads
              << ",rounds=" << rounds
              << ",wait_ms=" << wait_ms
              << ",elapsed_seconds=" << elapsed_seconds
              << ",cpu_seconds=" << cpu_seconds
              << ",cpu_to_elapsed_ratio=" << cpu_to_elapsed_ratio
              << "\n";
}

void run_blocking_wait(int threads, int rounds, int wait_ms) {
    std::mutex mutex;
    std::condition_variable cv;
    bool ready = false;

    std::vector<std::thread> workers;

    auto elapsed_start = Clock::now();
    double cpu_start = get_cpu_seconds();

    for (int t = 0; t < threads; t++) {
        workers.emplace_back([&, t]() {
            std::uint64_t local = static_cast<std::uint64_t>(t + 1);

            for (int r = 0; r < rounds; r++) {
                {
                    std::unique_lock<std::mutex> lock(mutex);
                    cv.wait(lock, [&]() {
                        return ready;
                    });
                }

                local += small_cpu_work(local + r, 1000);
            }

            global_sink += local;
        });
    }

    std::this_thread::sleep_for(std::chrono::milliseconds(wait_ms));

    {
        std::lock_guard<std::mutex> lock(mutex);
        ready = true;
    }

    cv.notify_all();

    for (auto& worker : workers) {
        worker.join();
    }

    double cpu_end = get_cpu_seconds();
    auto elapsed_end = Clock::now();

    double elapsed_seconds =
        std::chrono::duration<double>(elapsed_end - elapsed_start).count();

    double cpu_seconds = cpu_end - cpu_start;

    print_result("blocking_wait",
                 threads,
                 rounds,
                 wait_ms,
                 elapsed_seconds,
                 cpu_seconds);
}

void run_spin_wait(int threads, int rounds, int wait_ms) {
    std::atomic<bool> ready(false);
    std::vector<std::thread> workers;

    auto elapsed_start = Clock::now();
    double cpu_start = get_cpu_seconds();

    for (int t = 0; t < threads; t++) {
        workers.emplace_back([&, t]() {
            std::uint64_t local = static_cast<std::uint64_t>(t + 1);

            while (!ready.load(std::memory_order_acquire)) {
                local += small_cpu_work(local, 100);
            }

            for (int r = 0; r < rounds; r++) {
                local += small_cpu_work(local + r, 1000);
            }

            global_sink += local;
        });
    }

    std::this_thread::sleep_for(std::chrono::milliseconds(wait_ms));
    ready.store(true, std::memory_order_release);

    for (auto& worker : workers) {
        worker.join();
    }

    double cpu_end = get_cpu_seconds();
    auto elapsed_end = Clock::now();

    double elapsed_seconds =
        std::chrono::duration<double>(elapsed_end - elapsed_start).count();

    double cpu_seconds = cpu_end - cpu_start;

    print_result("spin_wait",
                 threads,
                 rounds,
                 wait_ms,
                 elapsed_seconds,
                 cpu_seconds);
}

void print_usage() {
    std::cerr << "Usage:\n"
              << "  ./parallel_time_metrics blocking_wait [threads] [rounds] [wait_ms]\n"
              << "  ./parallel_time_metrics spin_wait [threads] [rounds] [wait_ms]\n\n"
              << "Examples:\n"
              << "  ./parallel_time_metrics blocking_wait 8 1000 1000\n"
              << "  ./parallel_time_metrics spin_wait 8 1000 1000\n";
}

int main(int argc, char** argv) {
    if (argc < 2) {
        print_usage();
        return 1;
    }

    std::string mode = argv[1];

    int threads = 8;
    int rounds = 1000;
    int wait_ms = 1000;

    if (argc >= 3) {
        threads = std::atoi(argv[2]);
    }

    if (argc >= 4) {
        rounds = std::atoi(argv[3]);
    }

    if (argc >= 5) {
        wait_ms = std::atoi(argv[4]);
    }

    if (threads <= 0 || rounds <= 0 || wait_ms < 0) {
        print_usage();
        return 1;
    }

    if (mode == "blocking_wait") {
        run_blocking_wait(threads, rounds, wait_ms);
    } else if (mode == "spin_wait") {
        run_spin_wait(threads, rounds, wait_ms);
    } else {
        print_usage();
        return 1;
    }

    std::cerr << "sink=" << global_sink << "\n";
    return 0;
}