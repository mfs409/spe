#!/bin/bash

RESULT_DIR="results"
RESULT_FILE="${RESULT_DIR}/baseline_results.txt"
N=200000000

mkdir -p "${RESULT_DIR}"

{
    echo "Baseline Selection Experiment"
    echo "Host: $(hostname)"
    echo "Compiler: $(g++ --version | head -n 1)"
    echo "System: $(uname -a)"
    echo
    echo "Work size N=${N}"
    echo

    ./baseline_metrics sequential ${N}
    ./baseline_metrics parallel 1 ${N}
    ./baseline_metrics parallel 2 ${N}
    ./baseline_metrics parallel 4 ${N}
    ./baseline_metrics parallel 8 ${N}
    ./baseline_metrics parallel 16 ${N}

} > "${RESULT_FILE}" 2>&1

echo "Saved results to ${RESULT_FILE}"