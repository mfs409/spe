#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <string>
#include <thread>
#include <vector>

using Clock = std::chrono::steady_clock;

volatile std::uint64_t global_sink = 0;

std::uint64_t compute_work(std::uint64_t start, std::uint64_t end) {
    std::uint64_t local = 0;

    for (std::uint64_t i = start; i < end; i++) {
        std::uint64_t x = i + 1;
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        local += x;
    }

    return local;
}

double elapsed_seconds(Clock::time_point start, Clock::time_point end) {
    return std::chrono::duration<double>(end - start).count();
}

void run_sequential(std::uint64_t n) {
    auto start = Clock::now();

    std::uint64_t result = compute_work(0, n);

    auto end = Clock::now();

    global_sink += result;

    std::cout << "mode=sequential"
              << ",threads=1"
              << ",N=" << n
              << ",elapsed_seconds=" << elapsed_seconds(start, end)
              << "\n";
}

void run_parallel(std::uint64_t n, int threads) {
    std::vector<std::thread> workers;
    std::vector<std::uint64_t> partials(threads, 0);

    auto start = Clock::now();

    std::uint64_t chunk = n / threads;

    for (int t = 0; t < threads; t++) {
        std::uint64_t begin = static_cast<std::uint64_t>(t) * chunk;
        std::uint64_t end = (t == threads - 1)
            ? n
            : static_cast<std::uint64_t>(t + 1) * chunk;

        workers.emplace_back([&, t, begin, end]() {
            partials[t] = compute_work(begin, end);
        });
    }

    for (auto& worker : workers) {
        worker.join();
    }

    std::uint64_t result = 0;

    for (std::uint64_t value : partials) {
        result += value;
    }

    auto end = Clock::now();

    global_sink += result;

    std::cout << "mode=parallel"
              << ",threads=" << threads
              << ",N=" << n
              << ",elapsed_seconds=" << elapsed_seconds(start, end)
              << "\n";
}

void print_usage() {
    std::cerr << "Usage:\n"
              << "  ./baseline_metrics sequential [N]\n"
              << "  ./baseline_metrics parallel [threads] [N]\n";
}

int main(int argc, char** argv) {
    if (argc < 2) {
        print_usage();
        return 1;
    }

    std::string mode = argv[1];

    std::uint64_t n = 200000000;

    if (mode == "sequential") {
        if (argc >= 3) {
            n = std::strtoull(argv[2], nullptr, 10);
        }

        run_sequential(n);
    } else if (mode == "parallel") {
        int threads = 1;

        if (argc >= 3) {
            threads = std::atoi(argv[2]);
        }

        if (argc >= 4) {
            n = std::strtoull(argv[3], nullptr, 10);
        }

        if (threads <= 0) {
            print_usage();
            return 1;
        }

        run_parallel(n, threads);
    } else {
        print_usage();
        return 1;
    }

    std::cerr << "sink=" << global_sink << "\n";
    return 0;
}