#!/bin/bash

N=1000000
Q=5000000

MEMORY_SIZE_MB=512
MEMORY_PASSES=5

SYSCALL_ITERATIONS=10000000

DISK_FILE="${HOME}/scratch/cse398_disk_test_file.tmp"
DISK_SIZE_MB=64
DISK_BLOCK_KB=1024

FILE_CREATE_DIR="${HOME}/scratch/cse398_file_create_test"
FILE_CREATE_COUNT=5000

RESULT_DIR="results"
RESULT_FILE="${RESULT_DIR}/benchmark_results.txt"

mkdir -p "${RESULT_DIR}"
mkdir -p "${HOME}/scratch"
mkdir -p "${FILE_CREATE_DIR}"

{
    echo "CSE 398 Performance Metrics Microbenchmarks"
    echo "Host: $(hostname)"
    echo "Compiler: $(g++ --version | head -n 1)"
    echo "System: $(uname -a)"
    echo

    echo "Data-structure lookup benchmarks"
    echo "N=${N}"
    echo "Q=${Q}"
    ./ds_metrics vector latency ${N} ${Q}
    ./ds_metrics vector throughput ${N} ${Q}
    ./ds_metrics unordered_map latency ${N} ${Q}
    ./ds_metrics unordered_map throughput ${N} ${Q}
    ./ds_metrics map latency ${N} ${Q}
    ./ds_metrics map throughput ${N} ${Q}
    echo

    echo "Memory bandwidth benchmark"
    ./system_metrics memory ${MEMORY_SIZE_MB} ${MEMORY_PASSES}
    echo

    echo "System-call latency benchmark"
    ./system_metrics syscall ${SYSCALL_ITERATIONS}
    echo

    echo "Disk write bandwidth benchmark"
    ./system_metrics disk_write "${DISK_FILE}" ${DISK_SIZE_MB} ${DISK_BLOCK_KB}
    rm -f "${DISK_FILE}"
    echo

    echo "File creation latency and throughput benchmark"
    ./system_metrics file_create "${FILE_CREATE_DIR}" ${FILE_CREATE_COUNT}
    rm -rf "${FILE_CREATE_DIR}"

} > "${RESULT_FILE}" 2>&1

echo "Saved benchmark results to ${RESULT_FILE}"