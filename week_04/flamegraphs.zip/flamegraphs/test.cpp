// a simple code to demonstrate how flamegraph works

#include <iostream>

using namespace std;

const int ITER = 100000000;

void Work_A() {
    volatile int x = 0;
    for (int i = 0; i < ITER; i++){
        x += i;
    }
}

void Work_B() {
    volatile int x = 0;
    for (int i = 0; i < ITER; i++){
        x += i * 2;
    }
}

void Work_C() {
    volatile int x = 0;
    for (int i = 0; i < ITER; i++){
        x += i * 3;
    }
}

void Work_D() {
    volatile int x = 0;
    for (int i = 0; i < ITER; i++){
        x += i * 4;
    }
}

void Work_E() {
    volatile int x = 0;
    for (int i = 0; i < ITER; i++){
        x += i * 5;
    }
}

int main() {
    Work_A();
    Work_B();
    Work_C();
    Work_D();
    Work_E();
}