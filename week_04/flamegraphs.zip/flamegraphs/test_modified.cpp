// a slight changed version of the other code to demonstrate how flame graph works on a not fully compile optimized code

#include <iostream>

using namespace std;

const int ITER = 100000000;

__attribute__((noinline))
void Work_A() {
    volatile int x = 0;
    for (int i = 0; i < ITER; i++){
        x += i;
    }
}

__attribute__((noinline))
void Work_B() {
    volatile int x = 0;
    for (int i = 0; i < ITER; i++){
        x += i * 2;
    }
}

__attribute__((noinline))
void Work_C() {
    volatile int x = 0;
    for (int i = 0; i < ITER; i++){
        x += i * 3;
    }
}

__attribute__((noinline))
void Work_D() {
    volatile int x = 0;
    for (int i = 0; i < ITER; i++){
        x += i * 4;
    }
}

__attribute__((noinline))
void Work_E() {
    volatile int x = 0;
    for (int i = 0; i < ITER; i++){
        x += i * 5;
    }
}

int main() {
    Work_A();
    Work_B();
    Work_C();
    Work_D();
    Work_E();
}